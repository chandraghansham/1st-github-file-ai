# HomeEase Services Logo

Website-ready logo asset for the HomeEase Services demo website.

## Add to your GitHub website

1. Upload the `assets` folder (including `home-services-logo.jpg`) to the same GitHub repository as `index.html`.
2. In `index.html`, place the logo where you want it to appear:

```html
<img src="assets/home-services-logo.jpg" alt="HomeEase Services logo" class="site-logo">
```

3. Add this CSS to `style.css`:

```css
.site-logo {
  display: block;
  width: min(100%, 260px);
  height: auto;
  object-fit: contain;
}
```

If you want to replace the logo text in your existing header, replace the existing `.brand` element with the `<img>` element above. Adjust `width` to fit your header.

Note: this logo file is a JPEG image with a white background. It is a visual asset only; it does not change the website code by itself.
